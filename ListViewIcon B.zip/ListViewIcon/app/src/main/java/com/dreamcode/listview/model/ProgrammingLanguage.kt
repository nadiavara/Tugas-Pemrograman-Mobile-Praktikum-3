package com.dreamcode.listview.model

class ProgrammingLanguage {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}